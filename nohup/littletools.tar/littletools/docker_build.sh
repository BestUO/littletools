#!/bin/bash
docker build -t littletools:v1.0-bate .