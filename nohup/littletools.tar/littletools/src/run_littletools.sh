#!/bin/bash
#这一步必须加，因为此脚本运行是workdir默认是/ 该目录下面找不到./trimule
cd /home/littletools
#表示将正常控制台输出忽略 将错误控制台输出显示到nohup文件中
nohup ./trimule > /dev/null  2>&1 &
#保持容器能正常后台运行
while true; do sleep 1; done
